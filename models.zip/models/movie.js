const { model, Schema } = require('mongoose');

const schema = new Schema(
    {
        id: {
            type: String,
            required: true
        },
        name: {
            type: String,
            required: true
        },
        photo: {
            type: String,
            required: true
        },
        director: {
            type: String,
            required: true
        },
        distribution: {
            from: {
                type: String,
                required: true
            }
        },
        type: {
            type: String,
            enum: ['MOVIE', 'SERIES'],
            required: true
        },
        seasons: {
            type: Number
        },
        episodes: {
            type: Number
        },
        rating: {
            type: Number
        },
        actors: [{
            name: {
                type: String
            },
            photo: {
                type: String
            },
            site: {
                type: String
            }
        }]
    },
    { timestamps: true }
);

module.exports = model('Movie', schema);
