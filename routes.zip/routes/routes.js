const express = require('express');
const movieRoutes = require('./movies');

const router = express.Router();

router.get('/', (req, res) => {
   res.send('Welcome to our Movie Site!!!');
});

router.get('/list', movieRoutes.index); //show list of movies
router.get('/movies/sort/:sortType/:sortBy', movieRoutes.getMovies); //sort movies by sort type - name, distribution date, ratings
router.get('/movies/:id', movieRoutes.getMovie); //read Movie by id

router.post('/movies', movieRoutes.createMovie); //create a movie
router.put('/movies/:id', movieRoutes.updateMovie); //update a movie by id
router.delete('/movies/:id', movieRoutes.deleteMovie); //delete a movie by id
router.post('/movies/:id/actors', movieRoutes.addActorToMovie); //add an actor to a movie given by id
router.delete('/movies/:id/actors/:name', movieRoutes.deleteActorFromMovie); //delete actor from a movie given by id.
module.exports = router;