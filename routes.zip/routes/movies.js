const movieModel = require('../models/movie');

const compareDates = (a, b) => {
    var dateA = new Date(a.distribution.from), dateB = new Date(b.distribution.from)
	return dateA - dateB
};

const compareRatings = (a, b) => {
	a = parseInt(a.rating);
    b = parseInt(b.rating);
    return (a < b) ? -1 : (a > b) ? 1 : 0;
};

const compareName = (a, b) => {
	a = a.name.toLowerCase();
    b = b.name.toLowerCase();
    return (a < b) ? -1 : (a > b) ? 1 : 0;
};

const index = async (req, res) => {
    const movies = await movieModel.find();
    res.send(movies);
};

const getMovies = async (req, res) => {
    const { sortType, sortBy } = req.params;
    let movies = await movieModel.find();
    switch (sortType) {
        case 'name':
            movies = movies.sort(compareName);
            break;
        case 'rating':
            movies = movies.sort(compareRatings);
            break;
        default:
            movies = movies.sort(compareDates);
    }
    if (sortBy === 'asc') movies = movies.reverse();
    res.send(movies);
};

const createMovie = async (req, res) => {
    const movieData = req.body;
    await movieModel.create(movieData);
    res.status(200).send('new Movie added');
};

const getMovie = async (req, res) => {
    const { id } = req.params;
    const movie = await movieModel.findOne({ id });
    res.send(movie);
};

const updateMovie = async (req, res) => {
    const { id } = req.params;
    const movieData = req.body;
    if (movieData.type === 'MOVIE') {
        movieData.seasons = '';
        movieData.episodes = '';
    }
    await movieModel.updateOne({ id }, movieData);
    res.status(200).send(`movie id:${id} updated`);
};

const deleteMovie = async (req, res) => {
    const { id } = req.params;
    await movieModel.deleteOne({ id });
    res.status(200).send(`Movie id:${id} removed`);
};

const addActorToMovie = async (req, res) => {
    const { id } = req.params;
    const actorData = req.body;
    await movieModel.updateOne({ id }, { $push: { actors: actorData } });
    res.status(200).send('new site added');
};

const deleteActorFromMovie = async (req, res) => {
    const { id, name } = req?.params;
    const x = await movieModel.updateOne({ id }, { $pull: { actors: { name } } });
    console.log(x);
    res.status(200).send(`movie id:${id} actor name:${name} removed`);
}


module.exports = { index, getMovies, createMovie, getMovie, updateMovie, deleteMovie, addActorToMovie, deleteActorFromMovie };
